<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reservas extends CI_Controller{
	
function index(){
    $this->load->helper('form');
    $this->load->view("balneario");
}

}
?>