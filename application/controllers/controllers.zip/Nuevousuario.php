<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Nuevousuario extends CI_Controller {
        public $nombre;         
        public $dni; 
        public $fecha_nacimiento;
        public $email;
        public $direccion;
        public $telefono; 
        public $password; 
       

 public function index()
        {
                $this->load->helper('url');
                $this->load->view('header');   
                $this->load->helper(array('form', 'url'));
                $this->load->library('session');
                $this->nombre = $this->input->post('nombre');
                $this->dni = $this->input->post('dni');
                $this->direccion = $this->input->post('direccion');
                $this->telefono = $this->input->post('telefono');
                $this->email = $this->input->post('email');
                $this->fecha_nacimiento = $this->input->post('fecha_nacimiento'); 
                $this->password =$this->input->post('password');
                $passconf =$this->input->post('passconf');                
                $this->fecha_nacimiento = strtotime($this->fecha_nacimiento); 
                $this->fecha_nacimiento = date('Y-m-d',$this->fecha_nacimiento);            
                $this->load->library('form_validation');
                $this->form_validation->set_rules('nombre', 'nombre', 'trim|required|min_length[5]|max_length[30]|alpha_numeric_spaces',
        array(
                'required'      => 'No has escrito el nombre.',                
                'min_lenght[5]'     => 'necesita mas de 5 letras.',
                'max_lenght[30]'     => 'necesita menos de 30 letras.',
                'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
                $this->form_validation->set_rules('dni', 'dni', 'trim|required|max_length[9]|alpha_numeric_spaces|callback_validar_dni',
               array(
                'required'      => 'No has escrito el DNI .',
                'max_lenght[9]'     => 'Necesita escribir 8 cifras y una  letra',
                'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
        
                $this->form_validation->set_rules('direccion','direccion', 'trim|required|min_length[9]|max_length[100]',
                
             array(
                'required'      => 'No has escrito la direccion .',
                'min_lenght[9]'     => 'Necesita escribir mas de 9 characteres',
                'max_lenght[100]'     => 'Necesita escribir menos de 100 characteres'
                 
        ));
              $this->form_validation->set_rules('fecha_nacimiento','fecha_nacimiento','trim|required|callback_validar_fecha_nacimiento');
              $this->form_validation->set_rules('email','email','trim|required|valid_email');
               $this->form_validation->set_message('valid_email','El campo %s debe ser un email correcto');
              $this->form_validation->set_rules('telefono','telefono', 'trim|required|numeric|max_length[9]',
                 array(
                   'required'      => 'No has escrito el telefono .',
                   'max_lenght[9]'     => 'Necesita escribir  9 cifras',
                   'numeric'     => 'necesita solo cifras.'

      ));
           $this->form_validation->set_rules('password', 'Contraseña', 'trim|required');
           $this->form_validation->set_rules('passconf', 'Contraseña Confirmada', 'trim|required|matches[password]',
           array(
                'required'      => 'No has escrito la password .',
                'matches[password]'     => 'No son iguales'
         ));   
                $this->form_validation->set_message('min_length[9]','%s -se tienen que escribir 9 letras');
                if ($this->form_validation->run() == FALSE)
                {
                       //no ha sido validado
                       
                        $this->load->view('nuevousuario');
                }
                else
                {
                  // ha sido validado pues hay que meter en session
                   $this->load->model('tenis_model','',TRUE);
                    $this->nombre=$this->input->post('nombre');

               //buscar antes si la persona existe con el nombre
                 if($this->nombre!=null){
                   $data['query'] = $this->tenis_model->get_usuario_nombre();
                   if($data['query']!=null){
                    //existe en la tabla
                      $this->load->view('nuevousuario',$data);}
                   else{
                 $nuevousuario = array(
                    'nombre'  => $this->nombre,
                    'dni'     => $this->dni,
                    'direccion' =>$this->direccion,
                    'fecha_nacimiento'=>$this->fecha_nacimiento,
                    'telefono'=>$this->telefono,
                     'email'=>$this->email,
                    'password' =>$this->password
);
                
                  $this->tenis_model->insert_usuario();
                  


                  $this->session->set_userdata($nuevousuario);
                          
                        $this->load->view('usuario');
                }}}


      $this->load->view('footer');
}




public function validar_dni($dni){
           $letra = substr($dni, -1);
          $numeros = substr($dni, 0, -1);
        if ( substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letra && strlen($letra) == 1 && strlen ($numeros) == 8 ){
               return TRUE;
        }else{
               $this->form_validation->set_message('validar_dni',
        '{dni} formato de dni no valido');
          return FALSE;
        }
       }   
          public function validar_fecha_nacimiento($str){
                if(preg_match('#[0-9]{4}\-[0-9]{2}\-[0-9]{2}#', $str))
                             
                {
                return TRUE;
                }
                else
        {
        $this->form_validation->set_message('validar_fecha_nacimiento', '{fecha_nacimiento} tiene que ser aaaa-mm-dd');
        
      return FALSE;
     }
   }

}