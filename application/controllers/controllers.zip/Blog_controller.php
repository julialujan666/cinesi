<?php 
class Blog_controller extends CI_Controller {
        public function index()  {
        	$this->load->helper('form');
        	$this->load->view('blog');
        }

        public function View1()  {
           	$this->load->helper('form');
            $this->load->model('blog_model','',TRUE);
            $data['query'] = $this->blog_model->get_last_ten_entries();
            $this->load->view('view1', $data);
          }
            
  public function View2()  {
            $this->load->helper('form');
            $this->load->model('blog_model','',TRUE);
            $data1['query'] = $this->blog_model->get_entries();
            $this->load->view('view2', $data1);
          }
         
     public function View3()  {
             $this->load->helper('url');           
            $this->load->helper('form');
            $this->load->model('blog_model','',TRUE);             
             $this->load->view('view3');
              $data2['query'] = $this->blog_model->get_param_entries();  
            $this->load->view('view3', $data2);
          }       

                
   public function View5()  {               
            $this->load->helper('form');
            $this->load->model('blog_model','',TRUE);          
                         
            $data3['query'] = $this->blog_model->insert_entry();  
            $this->load->view('view5', $data3);
          }              

}

?>