<?php

class Contacto extends CI_Controller {

        public function index()
        {
             $this->load->helper('url');
             $this->load->view('header');
   
               $this->load->helper(array('form', 'url'));
               $nombre = $this->input->post('nombre');
               $email = $this->input->post('email');
               $tema = $this->input->post('tema');
               $comment = $this->input->post('comment');      
               $this->load->library('form_validation');
                $this->form_validation->set_rules('nombre', 'nombre', 'trim|required|min_length[5]|max_length[30]|alpha_numeric_spaces',
        array(
                'required'      => 'No has escrito el nombre.',                
                'min_lenght[5]'     => 'necesita mas de 5 letras.',
                'max_lenght[30]'     => 'necesita menos de 30 letras.',
                'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
        
                $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email',
        array(
                'required'      => 'No has escrito el correo.',                
                'valid_email'   =>'No has escrito un correo valido'
                
        ));

                $this->form_validation->set_rules('tema','tema', 'trim|required|min_length[10]|max_length[100]',
                
             array(
                'required'      => 'No has escrito el tema .',
                'min_lenght[10]'     => 'Necesita escribir mas de 10 characteres',
                'max_lenght[100]'     => 'Necesita escribir menos de 100 characteres'
                 
        ));
              
            $this->form_validation->set_rules('comment', 'comment', 'trim|required',
        array(
                'required'      => 'No has escrito el mensaje.',                
               
        ));
          
                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('contacto');
                }
                else{
                      $this->load->helper('text');
                      $disallowed = array('futbol', 'tonto');
                     $comment = word_censor($comment, $disallowed, ' ');

                      
                       echo $comment;
                       //ecsribir con la consola javascript
                    $this->load->view('inicio');
                }
               
            $this->load->view('footer');
            }

 

}
