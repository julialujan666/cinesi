<?php

class Persona extends CI_Controller {

        public function index()
        {
                $this->load->helper(array('form', 'url'));
                $nombre = $this->input->post('nombre');
               $dni = $this->input->post('dni');
               $direccion = $this->input->post('direccion');
               $telefono = $this->input->post('telefono');
               $fecha = $this->input->post('email');              
                $this->load->library('form_validation');

                $this->form_validation->set_rules('nombre', 'nombre', 'trim|required|min_length[5]|max_length[30]|alpha_numeric_spaces',
        array(
                'required'      => 'No has escrito el nombre.',                
                'min_lenght[5]'     => 'necesita mas de 5 letras.',
                'max_lenght[30]'     => 'necesita menos de 30 letras.',
                'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
                $this->form_validation->set_rules('dni', 'dni', 'trim|required|max_length[9]|alpha_numeric_spaces|callback_validar_dni',
               array(
                'required'      => 'No has escrito el DNI .',
                'max_lenght[9]'     => 'Necesita escribir 9 cifras y una  letra',
                 'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
        
                $this->form_validation->set_rules('direccion','direccion', 'trim|required|min_length[10]|max_length[100]',
                
             array(
                'required'      => 'No has escrito la direccion .',
                'min_lenght[9]'     => 'Necesita escribir mas de 10 characteres',
                'max_lenght[100]'     => 'Necesita escribir menos de 100 characteres'
                 
        ));
              $this->form_validation->set_rules('email','email','required');
            
              $this->form_validation->set_rules('telefono','telefono', 'required|numeric|max_length[9]',
                 array(
                   'required'      => 'No has escrito el telefono .',
                   'max_lenght[9]'     => 'Necesita escribir  9 cifras',
                   'numeric'     => 'necesita solo cifras.'

      ));
          
                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('persona2');
                }
                else
                {
                       
                         $this->load->library('table');
$data1 = array(
array('Campo', 'Valor'),
array('nombre', $nombre),
array('dni', $dni),
array('direccion', $direccion),
array('email', $email),
array('telefono', $telefono)
);
$template1 = array(
'table_open' => '<table border="0"
cellpadding="4" cellspacing="0">',
'thead_open' => '<thead>',
'thead_close' => '</thead>',
'heading_row_start' => '<tr>',
'heading_row_end' => '</tr>',
'heading_cell_start' => '<th>',
'heading_cell_end' => '</th>',
'tbody_open' => '<tbody>',
'tbody_close' => '</tbody>',
'row_start' => '<tr>',
'row_end' => '</tr>',
'row_end' => '</tr>',
'cell_start' => '<td>',
'cell_end' => '</td>',
'row_alt_start' => '<tr>',
'row_alt_end' => '</tr>',
'cell_alt_start' => '<td>',
'cell_alt_end' => '</td>',
'table_close' => '</table>'
);
$this->table->set_template($template1);
echo $this->table->generate($data1);
                        $this->load->view('formsuccess',$data1);
                }
        }




public function validar_dni($dni){
           $letra = substr($dni, -1);
          $numeros = substr($dni, 0, -1);
        if ( substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letra && strlen($letra) == 1 && strlen ($numeros) == 8 ){
               return TRUE;
        }else{
               $this->form_validation->set_message('validar_dni',
        '{dni} formato de dni no valido');
          return FALSE;
        }
       }   
         




}