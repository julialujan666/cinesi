<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Usuario extends CI_Controller {

        public function index()
        {
             $this->load->helper('url');
             $this->load->library('session');
             $this->load->view('header');
             $this->load->helper(array('form', 'url'));
             $usuario = $this->input->post('username');
             $password = $this->input->post('password');
             $this->load->library('form_validation');
             $this->form_validation->set_rules('username', 'Username','callback_username_check');
             $this->form_validation->set_rules('password', 'Password','callback_password_check');

                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('usuario');
                }
                else{
                    
                    $this->load->view('contacto');
                }
               
            $this->load->view('footer');
            }
    



public function username_check($str) {

if(isset($_SESSION['nombre'])){
    $username=$_SESSION['nombre'];
}
if ($str !== $username) {
$this->form_validation->set_message('username_check','El usuario incorrecto!');
return FALSE;
}
else { return TRUE; } }

public function password_check($str) {
if(isset($_SESSION['password'])){
    $password=$_SESSION['password'];
}
if ($str !== $password) {
$this->form_validation->set_message('password_check','La contraseña incorrecta!');
return FALSE;
}
else { return TRUE; } }
}
?>               