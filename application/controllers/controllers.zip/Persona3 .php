 <?php
 defined('BASEPATH') OR exit('No direct script access allowed');

class Persona3 extends CI_Controller {
        public function index()  {
 
           //enseña la tabla
            $this->load->helper('form');
            $this->load->model('persona_model','',TRUE);
            //un formulario con dni
            $this->load->view('persona3');
            if(  $this->input->post('dni')!=null  ){
             
            $data['query'] = $this->persona_model->get_persona_dni();
            //un formulario con los datos 
           $this->load->view('persona4', $data);
          }}}

          ?>