<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Empleado extends CI_Controller{
	
function nuevo_empleado(){
    $this->load->helper('form');
    $this->load->view("formulario2");
}
function index(){
    $this->load->helper('form');
    $this->load->view("formulario2");
}
}
?>