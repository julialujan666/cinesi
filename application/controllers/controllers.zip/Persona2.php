<?php 


defined('BASEPATH') OR exit('No direct script access allowed');

class Persona2 extends CI_Controller {
        public function index()  {
        	    $this->load->helper('form');
        	    $this->load->model('persona_model','',TRUE);
              $this->load->helper(array('form', 'url'));
               $nombre = $this->input->post('nombre');
               $dni = $this->input->post('dni');
               $direccion = $this->input->post('direccion');
               $telefono = $this->input->post('telefono');
               $fecha = $this->input->post('email');              
               $this->load->library('form_validation');
               $this->form_validation->set_rules('nombre', 'nombre', 'trim|required|min_length[5]|max_length[30]|alpha_numeric_spaces');
                $this->form_validation->set_message('max_length[30]','El campo %s debe tener max 30 caracteres');
                $this->form_validation->set_rules('dni', 'dni', 'trim|required|max_length[9]|alpha_numeric_spaces|callback_validar_dni',
               array(
                'required'      => 'No has escrito el DNI .',
                'max_lenght[9]'     => 'Necesita escribir 9 cifras y una  letra',
                 'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
        
               $this->form_validation->set_rules('direccion','direccion', 'trim|required|min_length[9]|max_length[100]');
            
                $this->form_validation->set_message('max_length[100]','El campo %s debe tener max 100 cracteres');
               $this->form_validation->set_message('min_length[9]','El campo %s debe tener mas de 9 caracteres');
            
              $this->form_validation->set_rules('email','email','trim|required|valid_email');
            
              $this->form_validation->set_rules('telefono','telefono', 'required|numeric|max_length[9]');                
              $this->form_validation->set_message('max_length[9]','El campo %s debe tener max 9 cifras');
             
             $this->form_validation->set_message('required','El campo %s es obligatorio'); 
             $this->form_validation->set_message('alpha_numeric_spaces','El campo %s debe estar compuesto solo por letras y spacios');
             $this->form_validation->set_message('numeric','El campo %s debe estar compuesto solo por cifras');
             $this->form_validation->set_message('min_length[5]','El campo %s debe tener mas de 5 caracteres');
             $this->form_validation->set_message('min_length[9]','El campo %s debe tener mas de 9 caracteres');
             $this->form_validation->set_message('valid_email','El campo %s debe ser un email correcto');
                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('persona2');
                }
                else
                {

            $data1['query'] = $this->persona_model->insert_persona();  

            $this->load->view('persona_test');
          }}
           

 public function validar_dni($dni){
           $letra = substr($dni, -1);
          $numeros = substr($dni, 0, -1);
        if ( substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letra && strlen($letra) == 1 && strlen ($numeros) == 8 ){
               return TRUE;
        }else{
               $this->form_validation->set_message('validar_dni','{dni} formato de dni no valido');
          return FALSE;
        }
       }   

}

?>