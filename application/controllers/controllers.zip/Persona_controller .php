<?php 
defined('BASEPATH') OR exit('No direct script access allowed');



class Persona_controller extends CI_Controller {
        public function index()  {
        	$this->load->helper('form');
        	$this->load->view('persona_test');
        }

        public function Persona1()  {
           //enseña la tabla
           	$this->load->helper('form');
            $this->load->model('persona_model','',TRUE);
            $data['query'] = $this->persona_model->get_persona();
            $this->load->view('persona1', $data);
          }
            


}

?>