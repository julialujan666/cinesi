<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quienes extends CI_Controller {

	
	public function index()
	{
	$this->load->helper('url');
    $this->load->view('header');
    $this->load->library('table');
 
     $this->load->model('cargo_model','',TRUE);
     $data['query'] = $this->cargo_model->get_cargo();                   

   
    $this->load->view('quienes',$data);

    $this->load->view('footer');
	}
 
 }

?>