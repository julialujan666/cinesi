 <?php
 defined('BASEPATH') OR exit('No direct script access allowed');

class Persona4 extends CI_Controller {
        public $nombre;         
        public $dni; 
        public $fecha_nacimiento;
        public $email;
        public $direccion;
        public $telefono;  
          
        public function index()  {
         
           //enseña la tabla
              $this->load->helper('form');
              $this->load->model('persona_model','',TRUE);
            //un formulario con dni
              $this->load->view('persona3');
              $this->load->library('form_validation');
              $this->form_validation->set_rules('dni', 'dni', 'trim|required|max_length[9]|alpha_numeric_spaces|callback_validar_dni',
                  array(
                'required'      => 'No has escrito el DNI .',
                'max_lenght[9]'     => 'Necesita escribir 9 cifras y una  letra',
                 'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
                    ));
               if($this->form_validation->run() == TRUE) {
                   $this->dni = $this->input->post('dni'); }
               

               if(  ($this->dni!=null) && ($this->form_validation->run() == FALSE) ){
                 $data['query'] = $this->persona_model->get_persona_dni(); 
                 $this->load->view('persona4',$data);           
                 $this->load->helper(array('form', 'url'));     
                 
                $this->form_validation->set_rules('nombre', 'nombre', 'trim|required|min_length[5]|max_length[30]|alpha_numeric_spaces');
                $this->form_validation->set_message('max_length[30]','El campo %s debe tener max 30 caracteres');
               
        
                $this->form_validation->set_rules('direccion','direccion', 'trim|required|min_length[9]|max_length[100]');
            
                $this->form_validation->set_message('max_length[100]','El campo %s debe tener max 100 cracteres');
                $this->form_validation->set_message('min_length[9]','El campo %s debe tener mas de 9 caracteres');
            
                $this->form_validation->set_rules('email','email','trim|required|valid_email');
                $this->form_validation->set_rules('fecha_nacimiento','fecha_nacimiento','trim|required');
            
                $this->form_validation->set_rules('telefono','telefono', 'required|numeric|max_length[9]');                
                $this->form_validation->set_message('max_length[9]','El campo %s debe tener max 9 cifras');
             
                $this->form_validation->set_message('required','El campo %s es obligatorio'); 
                $this->form_validation->set_message('alpha_numeric_spaces','El campo %s debe estar compuesto solo por letras y spacios');
                $this->form_validation->set_message('numeric','El campo %s debe estar compuesto solo por cifras');
                $this->form_validation->set_message('min_length[5]','El campo %s debe tener mas de 5 caracteres');
                $this->form_validation->set_message('min_length[9]','El campo %s debe tener mas de 9 caracteres');
                $this->form_validation->set_message('valid_email','El campo %s debe ser un email correcto');
               }
                else
                {
            
              $this->dni=$this->input->post('dni');         
             
             //poner otro formulario donde entran los datos de la tabla
             //leer las modificaciones   
             $this->nombre  = $this->input->post('nombre'); 
             $this->fecha_nacimiento = $this->input->post('fecha_nacimento');         
             
             $this->email  = $this->input->post('email'); 
             $this->direccion  = $this->input->post('direccion'); 
             $this->telefono  = $this->input->post('telefono');  
           $data1=array(
             "nombre"=> $this->nombre,
             "dni"=> $this->dni,
             "direccion"=> $this->direccion,
             "fecha_nacimiento"=> $this->fecha_nacimiento,
             "email"=> $this->email,             
             "telefono"=>$this->telefono
           );  
             var_dump($data1);
                    $this->persona_model->update_persona($data1,$this->dni);  
           
            $this->load->view('persona4');
          }}
           

 public function validar_dni($dni){
          $letra = substr($dni, -1);
          $numeros = substr($dni, 0, -1);
        if ( substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letra && strlen($letra) == 1 && strlen ($numeros) == 8 ){
               return TRUE;
        }else{
               $this->form_validation->set_message('validar_dni','{dni} formato de dni no valido');
          return FALSE;
        }
       }   


}

?>

           

        

        