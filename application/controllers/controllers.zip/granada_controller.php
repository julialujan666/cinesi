<?php 
class Granada_controller extends CI_Controller {
        public $nombre;         
        public $dni; 
        public $fecha_nacimiento;
        public $email;
        public $direccion;
        public $telefono; 
        public $password; 
        public $usuario;
        public $nuevousuario;
    public function index()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('templates/granada_cabecera');
       	// vista concreta
          $this->load->view('pages/granada');
       	$this->load->view('templates/granada_pie');
    }
    public function historia()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('templates/granada_cabecera');
       	// vista concreta
         $this->load->view('pages/historia');
       	$this->load->view('templates/granada_pie');
    }
    public function galeria()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('templates/granada_cabecera');
       	// vista concreta
         $this->load->view('pages/galeria');
       	$this->load->view('templates/granada_pie');
    }
    public function region()  {        	
    	// helpers y libraries
    	$this->load->helper('url');
       	$this->load->view('templates/granada_cabecera');
       	// vista concreta
         $this->load->view('pages/region');
       	$this->load->view('templates/granada_pie');
    }
  

    public function Usuario()  {        	
    	// helpers y libraries
    	$this->load->helper('form');
      $this->load->helper('url');
      $this->load->library('session');
      $this->load->view('templates/granada_cabecera');
        // vista concreta     
     
     
      $this->load->model('granada_model','',TRUE);
      $this->nombre=$this->input->post('nombre');
      $this->password=$this->input->post('password');
               //buscar antes si la persona existe con el nombre
      $this->load->helper(array('form', 'url'));
      $this->load->library('form_validation');
      $this->form_validation->set_rules('nombre', 'Nombre','trim|required|alpha_numeric');
      $this->form_validation->set_rules('password', 'Password','trim|required|alpha_numeric');

      if ($this->form_validation->run() == FALSE)
                {
                  
        // vista concreta     
                 $this->load->view('pages/usuario'); 
                
                }
                else{
                  
                   if(($this->nombre!=null)&&($this->password!=null)){
                     $query = $this->granada_model->get_usuario_nombre_password();
//meter data en session si estan 
               
                if($query!=null){
                  //escribir en session todo los datos de usuario
                    
                    $usuario = array(
                    'nombre'  => $this->nombre,
                    'password' =>$this->password,                   
                    'dni'     =>$query[0]->dni,
                    'direccion' =>$query[0]->direccion,
                    
                    'fecha_nacimiento'=>strtotime($query[0]->fecha_nacimiento),
                    'telefono'=>strval($query[0]->telefono),
                     'email'=>$query[0]->email
                   
);
                 $this->session->set_userdata($usuario);
           
                    $this->load->view('pages/formsuccess');
                }
               
             $this->load->view('templates/granada_pie');
            }
    
  

    }}

 public function Nuevousuario()  {         
      // helpers y libraries
      $this->load->helper('form');
      $this->load->helper('url');
      $this->load->view('templates/granada_cabecera');
             // vista concreta        
      $this->load->helper('url');    
      $this->load->helper(array('form', 'url'));
      $this->load->library('session');
      $this->nombre = $this->input->post('nombre');
      $this->dni = $this->input->post('dni');
      $this->direccion = $this->input->post('direccion');
      $this->telefono = $this->input->post('telefono');
      $this->email = $this->input->post('email');
      $this->fecha_nacimiento = $this->input->post('fecha_nacimiento'); 
      $this->password =$this->input->post('password');
      $passconf =$this->input->post('passconf');                
      $this->fecha_nacimiento = strtotime($this->fecha_nacimiento); 
      $this->fecha_nacimiento = date('Y-m-d',$this->fecha_nacimiento);            
      $this->load->library('form_validation');
      $this->form_validation->set_rules('nombre', 'nombre', 'trim|required|min_length[5]|max_length[30]|alpha_numeric_spaces',
        array(
                'required'      => 'No has escrito el nombre.',                
                'min_lenght[5]'     => 'necesita mas de 5 letras.',
                'max_lenght[30]'     => 'necesita menos de 30 letras.',
                'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
                $this->form_validation->set_rules('dni', 'dni', 'trim|required|max_length[9]|alpha_numeric_spaces|callback_validar_dni',
               array(
                'required'      => 'No has escrito el DNI .',
                'max_lenght[9]'     => 'Necesita escribir 8 cifras y una  letra',
                'alpha_numeric_spaces'     => 'necesita solo characteres y espacios.'
        ));
        
                $this->form_validation->set_rules('direccion','direccion', 'trim|required|min_length[9]|max_length[100]',
                
             array(
                'required'      => 'No has escrito la direccion .',
                'min_lenght[9]'     => 'Necesita escribir mas de 9 characteres',
                'max_lenght[100]'     => 'Necesita escribir menos de 100 characteres'
                 
        ));
              $this->form_validation->set_rules('fecha_nacimiento','fecha_nacimiento','trim|required|callback_validar_fecha_nacimiento');
              $this->form_validation->set_rules('email','email','trim|required|valid_email');
               $this->form_validation->set_message('valid_email','El campo %s debe ser un email correcto');
              $this->form_validation->set_rules('telefono','telefono', 'trim|required|numeric|max_length[9]',
                 array(
                   'required'      => 'No has escrito el telefono .',
                   'max_lenght[9]'     => 'Necesita escribir  9 cifras',
                   'numeric'     => 'necesita solo cifras.'

      ));
           $this->form_validation->set_rules('password', 'Contraseña', 'trim|required');
           $this->form_validation->set_rules('passconf', 'Contraseña Confirmada', 'trim|required|matches[password]',
           array(
                'required'      => 'No has escrito la password .',
                'matches[password]'     => 'No son iguales'
         ));   
                $this->form_validation->set_message('min_length[9]','%s -se tienen que escribir 9 letras');
                if ($this->form_validation->run() == FALSE)
                {
                       //no ha sido validado
                       
                        $this->load->view('pages/nuevousuario');
                }
                else
                {
                  // ha sido validado pues hay que meter en session
                   $this->load->model('granada_model','',TRUE);
                   $this->nombre=$this->input->post('nombre');

               //buscar antes si la persona existe con el nombre
                 if($this->nombre!=null){
                   $data['query'] = $this->granada_model->get_usuario_nombre();
                   if($data['query']!=null){
                    //existe en la tabla
                      $this->load->view('pages/nuevousuario',$data);}
                   else{
                 $nuevousuario = array(
                    'nombre'  => $this->nombre,
                    'dni'     => $this->dni,
                    'direccion' =>$this->direccion,
                    'fecha_nacimiento'=>$this->fecha_nacimiento,
                    'telefono'=>$this->telefono,
                     'email'=>$this->email,
                    'password' =>$this->password
);
                
                  $this->granada_model->insert_usuario();                 


                  $this->session->set_userdata($nuevousuario);
                          
                        $this->load->view('pages/usuario');
                }}}


      $this->load->view('templates/granada_pie');
}
public function logout(){

if(isset($_SESSION['nombre'])&&isset($_SESSION['password'])){

 $array_items = array('nombre' => $_SESSION['nombre'],
                       'password'=>$_SESSION['password'],
                       'dni'     => $_SESSION['dni'],
                       'direccion' =>$_SESSION['direccion'],
                       'fecha_nacimiento'=>$_SESSION['fecha_nacimiento'],
                       'telefono'=>$this->$_SESSION['telefono'],
                       'email' => $_SESSION['email']);

$this->session->unset_userdata($array_items);


if(empty($_SESSION['nombre']) && empty($_SESSION['password']))
{

  $this->load->view('templates/granada_cabecera');
        // vista concreta
  $this->load->view('pages/granada');
  $this->load->view('templates/granada_pie');
}
else
{
echo "Ha habido un error, trata de desloguearte nuevamente<br>";
} 
}}

public function nombre_check($str) {

if(isset($_SESSION['nombre'])){
    $nombre=$_SESSION['nombre'];
}
if ($str !== $nombre) {
$this->form_validation->set_message('nombre_check','El usuario incorrecto!');
return FALSE;
}
else { return TRUE; } }

public function password_check($str) {
if(isset($_SESSION['password'])){
    $password=$_SESSION['password'];
}
if ($str !== $password) {
$this->form_validation->set_message('nombre_check','La contraseña incorrecta!');
return FALSE;
}
else { return TRUE; 
} }


public function validar_dni($dni){
           $letra = substr($dni, -1);
          $numeros = substr($dni, 0, -1);
        if ( substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letra && strlen($letra) == 1 && strlen ($numeros) == 8 ){
               return TRUE;
        }else{
               $this->form_validation->set_message('validar_dni',
        '{dni} formato de dni no valido');
          return FALSE;
        }
       }   
 public function validar_fecha_nacimiento($str){
                if(preg_match('#[0-9]{4}\-[0-9]{2}\-[0-9]{2}#', $str))
                             
                {
                return TRUE;
                }
                else
        {
        $this->form_validation->set_message('validar_fecha_nacimiento', '{fecha_nacimiento} tiene que ser aaaa-mm-dd');
        
      return FALSE;
     }
   }


}
?>